/*
  OQO Display tool
  Run video BIOS code for various purposes on OQO (currently only Model 01)
  Moshen Chan <moshen@oqo.com> 5/9/05

  Based on vbetool by Matthew Garrett <mjg59@srcf.ucam.org>

*/

#include <pci/pci.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/io.h>
#include <sys/kd.h>
#include <sys/stat.h>
#include <errno.h>

#include "lrmi.h"
#include "oqodisptool.h"


#define access_ptr_register(reg_frame,reg) (reg_frame -> reg)
#define real_mode_int(interrupt,reg_frame_ptr) !LRMI_int(interrupt,reg_frame_ptr)

/* static struct pci_access *pacc; */

int main(int argc, char *argv[])
{
	if (!LRMI_init())
		return 1;

	ioperm(0, 1024, 1);
	iopl(3);

/* 	pacc = pci_alloc(); */
/* 	pacc->numeric_ids = 1; */
/* 	pci_init(pacc); */

	if (!strcmp(argv[1], "internal")) {
	    return do_lcd_switch();
	} else if (!strcmp(argv[1], "external")) {
	    return do_crt_switch();
	} else if (!strcmp(argv[1], "toggledisplay")) {
	    return do_display_toggle();
	}

	else {
	    fprintf(stderr,
			"%s: Usage %s [[internal][external][toggledisplay]]\n",
			argv[0], argv[0]);
		return 1;
	}

	return 0;
}

int do_vbe_service(unsigned int AX, unsigned int BX, reg_frame * regs)
{
	const unsigned interrupt = 0x10;
	unsigned function_sup;
	unsigned success;

	access_ptr_register(regs, eax) = AX;
	access_ptr_register(regs, ebx) = BX;

	if (real_mode_int(interrupt, regs)) {
		fprintf(stderr,
			"Error: something went wrong performing real mode interrupt\n");
		return -1;
	}

	AX = access_ptr_register(regs, eax);

	function_sup = ((AX & 0xff) == 0x4f);
	success = ((AX & 0xff00) == 0);

	if (!success)
		return -2;
	if (!function_sup)
		return -3;

	return access_ptr_register(regs, ebx);
}



int do_lcd_switch() {
    reg_frame regs;
    int error;    
    
    memset(&regs, 0, sizeof(regs));
    error = do_vbe_service(0x5F13, 0, &regs);
    
    if (error<0) {
	return error;
    }
    return 0;

}

int do_crt_switch() {
    reg_frame regs;
    int error;    
    
    memset(&regs, 0, sizeof(regs));
    error = do_vbe_service(0x5F14, 0, &regs);
    
    if (error<0) {
	return error;
    }
    return 0;
}

int do_display_toggle() {
    reg_frame regs;
    int error;

    memset(&regs, 0, sizeof(regs));
    error = do_vbe_service(0x5F00, 0, &regs);

    if (((regs.edx >> 8) & 0xFF) == 2) {
	/* currently on CRT */
	error = do_lcd_switch();
    } else if (((regs.edx >> 8) & 0xFF) == 1) {
	/* currently on LCD */
	error = do_crt_switch();
    }

    if (error<0) {
	return error;
    }
    return 0;
} 
